# Webpage-About-Mythology
This is a basic web page built with HTML and CSS for my term project. For this web page, design was more important than content and usability. 
